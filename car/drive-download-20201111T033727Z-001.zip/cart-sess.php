<?php
session_start();
// $_SESSION["cart"]=array();
print_r($_SESSION["cart"]);

?>